package com.medicinealert.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicineAlertApplication {
    public static void main(String[] args) {
        SpringApplication.run(MedicineAlertApplication.class, args);
    }
}
