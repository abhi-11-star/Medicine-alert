package com.medicinealert.app.controller;

import com.medicinealert.app.model.Medicine;
import com.medicinealert.app.model.DoseLog;
import com.medicinealert.app.repository.MedicineRepository;
import com.medicinealert.app.repository.DoseLogRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class MedicineController {
    private final MedicineRepository medicines; private final DoseLogRepository logs;
    public MedicineController(MedicineRepository medicines,DoseLogRepository logs){this.medicines=medicines;this.logs=logs;}
    @GetMapping("/medicines") public List<Medicine> all(){return medicines.findAll();}
    @PostMapping("/medicines") @ResponseStatus(HttpStatus.CREATED) public Medicine add(@RequestBody Medicine m){
        if(blank(m.getName())||blank(m.getDosage())||blank(m.getAlertTime())||blank(m.getStartDate())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Name, dosage, date and time are required");
        if(m.getStock()<0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Stock cannot be negative");
        m.setId(null); if(blank(m.getInstructions()))m.setInstructions("As prescribed"); m.setEnabled(true); return medicines.save(m);
    }
    @DeleteMapping("/medicines/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id){if(!medicines.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND);medicines.deleteById(id);}
    @GetMapping("/logs") public List<DoseLog> history(){return logs.findTop100ByOrderByRecordedAtDesc();}
    @PostMapping("/medicines/{id}/status") public Map<String,Object> mark(@PathVariable Long id,@RequestBody Map<String,String> body){
        Medicine m=medicines.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Medicine not found"));
        String status=body.getOrDefault("status",""); if(!status.equals("Taken")&&!status.equals("Missed"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Status must be Taken or Missed");
        String date=body.getOrDefault("date",java.time.LocalDate.now().toString());
        // Avoid double stock deductions for duplicate Taken taps on the same medicine/date/time.
        List<DoseLog> all=logs.findAll();
        DoseLog previous=all.stream().filter(l->id.equals(l.getMedicineId())&&date.equals(l.getDoseDate())&&m.getAlertTime().equals(l.getDoseTime())).findFirst().orElse(null);
        if(previous!=null){if(!previous.getStatus().equals("Taken")&&status.equals("Taken"))m.setStock(Math.max(0,m.getStock()-1));previous.setStatus(status);previous.setRecordedAt(java.time.LocalDateTime.now());logs.save(previous);}
        else {if(status.equals("Taken"))m.setStock(Math.max(0,m.getStock()-1));logs.save(new DoseLog(id,m.getName(),date,m.getAlertTime(),status));}
        medicines.save(m); return Map.of("ok",true,"stock",m.getStock());
    }
    private boolean blank(String s){return s==null||s.trim().isEmpty();}
}
