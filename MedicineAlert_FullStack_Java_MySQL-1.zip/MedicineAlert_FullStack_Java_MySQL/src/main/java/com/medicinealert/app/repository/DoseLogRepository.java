package com.medicinealert.app.repository;
import com.medicinealert.app.model.DoseLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface DoseLogRepository extends JpaRepository<DoseLog,Long> { List<DoseLog> findTop100ByOrderByRecordedAtDesc(); }
