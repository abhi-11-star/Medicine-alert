package com.medicinealert.app.model;

import jakarta.persistence.*;

@Entity
@Table(name = "medicines")
public class Medicine {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false, length=100) private String name;
    @Column(nullable=false, length=100) private String dosage;
    @Column(nullable=false, length=10) private String alertTime;
    @Column(nullable=false, length=30) private String startDate;
    @Column(nullable=false, length=100) private String instructions = "As prescribed";
    private int stock;
    private boolean enabled = true;

    public Medicine() {}
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getName(){return name;} public void setName(String name){this.name=name;}
    public String getDosage(){return dosage;} public void setDosage(String dosage){this.dosage=dosage;}
    public String getAlertTime(){return alertTime;} public void setAlertTime(String alertTime){this.alertTime=alertTime;}
    public String getStartDate(){return startDate;} public void setStartDate(String startDate){this.startDate=startDate;}
    public String getInstructions(){return instructions;} public void setInstructions(String instructions){this.instructions=instructions;}
    public int getStock(){return stock;} public void setStock(int stock){this.stock=stock;}
    public boolean isEnabled(){return enabled;} public void setEnabled(boolean enabled){this.enabled=enabled;}
}
