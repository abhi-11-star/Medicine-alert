package com.medicinealert.app.repository;
import com.medicinealert.app.model.Medicine;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MedicineRepository extends JpaRepository<Medicine,Long> {}
