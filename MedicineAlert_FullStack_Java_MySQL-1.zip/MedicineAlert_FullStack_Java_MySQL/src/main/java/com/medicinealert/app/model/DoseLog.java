package com.medicinealert.app.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="dose_logs")
public class DoseLog {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private Long medicineId;
    @Column(nullable=false, length=100) private String medicineName;
    @Column(nullable=false, length=10) private String doseDate;
    @Column(nullable=false, length=10) private String doseTime;
    @Column(nullable=false, length=20) private String status;
    private LocalDateTime recordedAt;
    public DoseLog() {}
    public DoseLog(Long medicineId,String medicineName,String doseDate,String doseTime,String status){this.medicineId=medicineId;this.medicineName=medicineName;this.doseDate=doseDate;this.doseTime=doseTime;this.status=status;this.recordedAt=LocalDateTime.now();}
    public Long getId(){return id;} public Long getMedicineId(){return medicineId;} public String getMedicineName(){return medicineName;} public String getDoseDate(){return doseDate;} public String getDoseTime(){return doseTime;} public String getStatus(){return status;} public LocalDateTime getRecordedAt(){return recordedAt;}
    public void setId(Long id){this.id=id;} public void setMedicineId(Long v){medicineId=v;} public void setMedicineName(String v){medicineName=v;} public void setDoseDate(String v){doseDate=v;} public void setDoseTime(String v){doseTime=v;} public void setStatus(String v){status=v;} public void setRecordedAt(LocalDateTime v){recordedAt=v;}
}
