CREATE DATABASE IF NOT EXISTS medicine_alert CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- Spring Boot/JPA creates and updates the medicines and dose_logs tables on first startup.
