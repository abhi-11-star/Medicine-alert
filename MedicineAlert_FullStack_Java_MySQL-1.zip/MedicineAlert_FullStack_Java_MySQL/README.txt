MEDICINE ALERT — FULL-STACK JAVA + HTML + MYSQL
================================================

WHAT THIS PROJECT IS
- Java Spring Boot backend (REST API)
- Responsive HTML/CSS/JavaScript user interface
- MySQL database for medicine schedules and dose history
- Can be opened on Windows or on a mobile browser when the server is reachable
- Senior-friendly controls: large text, big buttons, high-contrast colours
- English/Malayalam language toggle and device text-to-speech (voice availability depends on browser/device)
- Repeating daily schedule; alert sound repeats until user responds; 5-minute snooze
- Taken/Missed tracking; stock decreases only when a dose is marked Taken
- Low stock warning and recent history

IMPORTANT HONEST LIMITATIONS
- This is a Java web application, not a native Android APK and not a standalone Windows EXE.
- A Java server and MySQL database must be installed/configured on the computer/server that hosts it.
- To use from a phone, run the server on a computer reachable on the same Wi-Fi, then open http://COMPUTER-LAN-IP:8080 on the phone. Firewall/network settings may need adjustment. For access outside the home/college network, it must be deployed securely to a server.
- The browser alarm works only while the page is open and the device/browser allows it to run. It is NOT guaranteed after closing the page, suspending the browser, sleeping/shutting down the device, or losing power. Do not rely on this prototype as the only reminder for critical medicines.
- Caregiver messages, authentication, HTTPS deployment, and native Android background alarms are not implemented in this version.
- This is a college prototype, not a certified medical device. Users must follow clinician/pharmacist instructions.

REQUIREMENTS
1. JDK 21 or later
2. Maven 3.9+ (or import pom.xml into a compatible IDE such as IntelliJ IDEA / NetBeans with Maven support)
3. MySQL 8.x running locally

MYSQL SETUP
1. Open MySQL Workbench or a MySQL command line.
2. Run database/create_database.sql.
3. Default configuration uses MySQL username root and an empty password. If your MySQL has a password, set environment variables before running:
   Windows CMD:
     set DB_USER=root
     set DB_PASSWORD=YOUR_MYSQL_PASSWORD
     mvn spring-boot:run
   PowerShell:
     $env:DB_USER="root"
     $env:DB_PASSWORD="YOUR_MYSQL_PASSWORD"
     mvn spring-boot:run
   Change DB_URL if MySQL is hosted elsewhere.
4. From this folder, run:
     mvn spring-boot:run
5. Open http://localhost:8080 in Chrome/Edge.

BUILD A JAR
  mvn clean package
  java -jar target/medicine-alert-1.0.0.jar

USE ON A PHONE ON THE SAME WI-FI
1. Start the server on the computer.
2. Find the computer's local IPv4 address (Windows CMD: ipconfig).
3. Allow inbound TCP port 8080 in Windows Firewall only on a trusted private network.
4. On the phone connected to the same Wi-Fi, open http://COMPUTER-IP:8080.
5. Keep the server computer awake and the page open. The app is responsive for mobile screens.

BASIC TEST CHECKLIST
- Add a test medicine scheduled 2–3 minutes ahead.
- Verify it appears in Today's medicines.
- Keep the page open; check that the alert rings and shows the medicine.
- Try Taken, Not taken, and Snooze.
- Verify Taken reduces stock once and creates history.
- Refresh the page and verify the schedule/history remain in MySQL.
- Test on the target phone/browser; alarm behaviour differs by device.

TROUBLESHOOTING
- "Cannot connect to Java server": make sure the backend started successfully and MySQL is running.
- MySQL access denied: set DB_USER and DB_PASSWORD to your MySQL credentials.
- Port in use: change server.port in src/main/resources/application.properties.
- Maven dependency download requires an internet connection the first time.

DATABASE
Spring Data JPA creates/updates medicines and dose_logs tables automatically on startup (ddl-auto=update). Back up the database regularly.
